package com.tra.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.tra.bean.CookieBean;
import com.tra.bean.SessionBean;

public class SessionRowMapper implements RowMapper<SessionBean> 
{

	public SessionBean mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		List list=null;
		SessionBean session=new SessionBean();
	//	CookieBean cookie=new CookieBean();
		session.setSessionId(rs.getString("session_id"));
		session.setSessionName(rs.getString("session_name"));
		session.setSessionValidity(rs.getString("session_validity"));
//		cookie.setSessionId(rs.getString("SESSION_ID"));
//		cookie.setCookieName(rs.getString("COOKIE_NAME"));
//		cookie.setCookieValue(rs.getString("COOKIE_VALUE"));
//		list.add(session);
//		list.add(cookie);
		return session;
	}

}
