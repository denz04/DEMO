package com.tra.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.tra.bean.CookieBean;

public class CookieRowMapper implements RowMapper<CookieBean>
{

	public CookieBean mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		CookieBean cookie=new CookieBean();
		
		cookie.setSessionId(rs.getString("SESSION_ID"));
		cookie.setCookieName(rs.getString("COOKIE_NAME"));
		cookie.setCookieValue(rs.getString("COOKIE_VALUE"));
		return cookie;
	}

}
