package com.tra.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.tra.bean.SessionCookieBean;



public class SessionCookieRowMapper implements RowMapper<SessionCookieBean>
{

	public SessionCookieBean mapRow(ResultSet rs, int rowNum)
			throws SQLException 
	{
		SessionCookieBean bean=new SessionCookieBean();
		bean.setCookieName(rs.getString("COOKIE_NAME"));
		bean.setCookieValue(rs.getString("COOKIE_VALUE"));
		bean.setSessionId(rs.getString("SESSION_ID"));
		bean.setSessionName(rs.getString("SESSION_NAME"));
		bean.setSessionValidity(rs.getString("SESSION_VALIDITY"));
		return bean;
	}

}
