package com.tra.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.tra.daoimpl.SessionDaoImpl;
import com.tra.bean.CookieBean;
import com.tra.bean.SessionBean;
@RestController
@RequestMapping(value="/sessions")
public class SessionController 
{
	@Autowired
	SessionDaoImpl daoImpl;
	@RequestMapping(value="/getallsessions" , method=RequestMethod.GET)
	public List<SessionBean> getSessionDetails()
	{
		List session=null;
		session=daoImpl.getSessionDetails();
		return session;
	}
	@RequestMapping(value="/createtable", method=RequestMethod.GET)
	public String createTable()
	{
		String s=String.valueOf(daoImpl.createTable());
		if(s.equals("1"))
			return "Created Successfully";
		else
			return "Failed";
	}
	@RequestMapping(value="/getallcookies" ,method=RequestMethod.GET)
	public List getCookieDetails()
	{
		List cookie=null;
		cookie=daoImpl.getCookieDetails();
		return cookie;
	}
	
	@RequestMapping(value="/insertsession",method=RequestMethod.POST)
	public String setSessionDetails(@RequestBody SessionBean bean,Model model)
	{
		System.out.println(bean.getSessionId());
		System.out.println("here");
		String session;
		session=String.valueOf(daoImpl.setSessionDetails(bean));
		if(session.equals("1"))
			return "Inserted Successfully";
		else
			return "Failed to Insert";
		
	}
	@RequestMapping(value="/insertcookie",method=RequestMethod.POST)
	public int setCookieDetails(@RequestBody CookieBean bean,Model model)
	{
		int cookie=0;
		cookie=daoImpl.setCookieDetails(bean);
		return cookie;
		
	}
	@RequestMapping(value="deletesession/{id}" ,method=RequestMethod.DELETE )
	public String deleteSession(@PathVariable("id") String id)
	{
		String result;
		result= String.valueOf(daoImpl.deleteSession(id));
		if(result.equals("1"))
			return "Deteled Successfully";
		else
			return "Record Doesnt Exist";
	}
	@RequestMapping(value="/updatesession",method=RequestMethod.PUT)
	public String updateSession(@RequestBody SessionBean bean)
	{
			String s=String.valueOf(daoImpl.updateSession(bean));
			if(s.equals("1"))
				return "Updated Successfully";
			else
				return "Failed to update";
	}
	@RequestMapping(value="/updatecookie" ,method=RequestMethod.PUT)
	public void updateCookie(@RequestBody CookieBean bean)
	{
		daoImpl.updateCookie(bean);
	}
	@RequestMapping(value="/getalldetails",method=RequestMethod.GET)
	public List getAllDetails()
	{
		List bean=null;
		bean=daoImpl.getFullDetails();
		return bean;
	}
}
