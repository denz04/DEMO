package com.tra.daoimpl;

import java.sql.Types;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.support.DaoSupport;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.tra.bean.CookieBean;
import com.tra.bean.SessionBean;
import com.tra.dao.ISessionValidationDAO;
import com.tra.rowmapper.CookieRowMapper;
import com.tra.rowmapper.SessionCookieRowMapper;
import com.tra.rowmapper.SessionRowMapper;
@Component
public class SessionDaoImpl extends JdbcDaoSupport implements ISessionValidationDAO
{

	@Autowired
	public SessionDaoImpl(DataSource dataSource)
	{
		setDataSource(dataSource);
	}
	public List getSessionDetails() 
	{
		List session=null;
		session=getJdbcTemplate().query("select * from T_XBBL5RG_SESSION ", new Object []{}, new SessionRowMapper());
		List s=session;
		return session;
	}
	public int createTable() 
	{
		
		int n=getJdbcTemplate().update("create table T_XBBL5RG_SESSION (SESSION_ID VARCHAR2(10), SESSION_NAME VARCHAR2(10),SESSION_VALIDITY VARCHAR2(10))");
		
		int r=getJdbcTemplate().update("create table T_XBBL5RG_COOKIE (SESSION_ID VARCHAR2(10),COOKIE_NAME VARCHAR2(10),COOKIE_VALUE VARCHAR2(10))");
		return n;
	}
	public List getCookieDetails() 
	{
		List cookie=null;
		cookie=getJdbcTemplate().query("select * from T_XBBL5RG_COOKIE ", new Object []{}, new CookieRowMapper());
		return cookie;
	}
	public int setSessionDetails(SessionBean bean) 
	{
		int session=0;
		session=getJdbcTemplate().update("insert into t_xbbl5rg_session values (?,?,?)", new Object []{bean.getSessionId(),bean.getSessionName(),bean.getSessionValidity()}, new int []{Types.VARCHAR,Types.VARCHAR,Types.VARCHAR});
		return session;
	}
	public int setCookieDetails(CookieBean bean) 
	{
		int cookie=0;
		cookie=getJdbcTemplate().update("insert into t_xbbl5rg_cookie values (?,?,?)", new Object []{bean.getSessionId(),bean.getCookieName(),bean.getCookieValue()}, new int []{Types.VARCHAR,Types.VARCHAR,Types.VARCHAR});
		return cookie;
	}
	public int deleteSession(String id) 
	{
		int n=getJdbcTemplate().update("delete from t_xbbl5rg_session where session_id=?", new Object []{id}, new int []{Types.VARCHAR});
		getJdbcTemplate().update("delete from t_xbbl5rg_cookie where session_id=?", new Object []{id}, new int []{Types.VARCHAR});
		System.out.println(n);
		return n;
	}
	public int updateSession(SessionBean bean) 
	{
		int n=getJdbcTemplate().update("update t_xbbl5rg_session set session_validity=?,session_name=? where session_id=?", new Object []{bean.getSessionValidity(),bean.getSessionName(),bean.getSessionId()}, new int []{Types.VARCHAR,Types.VARCHAR,Types.VARCHAR});
		return n;
		
	}
	public void updateCookie(CookieBean bean) 
	{
		getJdbcTemplate().update("update t_xbbl5rg_cookie set cookie_name=?,cookie_value=? where session_id=?", new Object []{bean.getCookieName(),bean.getCookieValue(),bean.getSessionId()}, new int []{Types.VARCHAR,Types.VARCHAR,Types.VARCHAR});
		
	}
	public List getFullDetails() 
	{
		List bean=null;
		bean=getJdbcTemplate().query("select t_xbbl5rg_session.session_id,t_xbbl5rg_session.session_name,t_xbbl5rg_session.session_validity,t_xbbl5rg_cookie.cookie_name,t_xbbl5rg_cookie.cookie_value from t_xbbl5rg_session join t_xbbl5rg_cookie on t_xbbl5rg_session.session_id=t_xbbl5rg_cookie.session_id", new Object []{}, new SessionRowMapper());
		return bean;
	}
	

}
