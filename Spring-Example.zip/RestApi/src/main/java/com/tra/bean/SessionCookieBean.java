package com.tra.bean;

public class SessionCookieBean 
{
	private String cookieName;
	private String sessionId;
	private String cookieValue;
	private String sessionName;
	private String SessionValidity;
	public String getCookieName() {
		return cookieName;
	}
	public void setCookieName(String cookieName) {
		this.cookieName = cookieName;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getCookieValue() {
		return cookieValue;
	}
	public void setCookieValue(String cookieValue) {
		this.cookieValue = cookieValue;
	}
	public String getSessionName() {
		return sessionName;
	}
	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
	public String getSessionValidity() {
		return SessionValidity;
	}
	public void setSessionValidity(String sessionValidity) {
		SessionValidity = sessionValidity;
	}
	
}
