package com.tra.bean;

public class SessionBean 
{
	private String sessionName;
	private String SessionId;
	private String SessionValidity;
	public String getSessionName() {
		return sessionName;
	}
	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
	public String getSessionId() {
		return SessionId;
	}
	public void setSessionId(String sessionId) {
		SessionId = sessionId;
	}
	public String getSessionValidity() {
		return SessionValidity;
	}
	public void setSessionValidity(String sessionValidity) {
		SessionValidity = sessionValidity;
	}
	
}
