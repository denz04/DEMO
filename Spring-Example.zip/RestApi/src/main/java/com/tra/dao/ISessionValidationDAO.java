package com.tra.dao;

import java.util.List;

import com.tra.bean.CookieBean;
import com.tra.bean.SessionBean;

public interface ISessionValidationDAO
{
	public List getSessionDetails();
	public int createTable();
	public List getCookieDetails();
	public int setSessionDetails(SessionBean bean);
	public int setCookieDetails(CookieBean bean);
	public int deleteSession(String id);
	public int updateSession(SessionBean bean);
	public void updateCookie(CookieBean bean);
	public List getFullDetails();
}
